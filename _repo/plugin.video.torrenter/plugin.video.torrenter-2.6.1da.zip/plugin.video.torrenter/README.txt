﻿Plugin helps you to watch videos from p2p torrent-networks, without full predownload (uses inner python-libtorrent) or Ace Stream. It also can add, control torrents and play downloaded files with external uTorrent, Transmission, Vuze or Deluge.
Official forum thread and FAQ: http://forums.tvaddons.ag/addon-releases/29224-torrenter-v2.html

Инструкции и обсуждение: http://xbmc.ru/forum/showthread.php?t=6837